#include"stm32f10x.h"

void SystemInit()
{
	


}

int main ()
{
	while(1)
	{
	
	}

}


