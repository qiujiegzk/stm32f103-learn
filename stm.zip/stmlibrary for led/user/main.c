#include<stm32f10x.h>
#include<LED.H>
typedef unsigned int u32;
void del(u32 a)
{
	while(a--);
}

int main ()
{
	ledInit();
	while(1)
	{
		
		ledon();
		del(0xfffff);
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
	}
}
