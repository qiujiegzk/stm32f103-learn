#ifndef __Systick1_H
#define __Systick1_H
#include<stm32f10x.h>




#endif

static u8 fac_us;
static u8 fac_ms;
void SysTick_Init(u8 SYSCLK);
void delay_us(u32 nus);
void delay_ms(u16 nms);
u8 delayms(u32 delay_time);
