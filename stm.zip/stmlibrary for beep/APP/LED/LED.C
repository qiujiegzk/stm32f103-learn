#include <LED.H>
#include <bitscontorl.h>
void ledInit (void)
{
	GPIO_InitTypeDef GPIO_InitStructure1;
	RCC_APB2PeriphClockCmd(LED2_PORT_RCC,ENABLE);
	GPIO_InitStructure1.GPIO_Pin=LED2_PIN;
	GPIO_InitStructure1.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure1.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure1);
	GPIO_SetBits(GPIOE,GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8);
	
	
	GPIO_InitTypeDef GPIO_InitStructure2;
	RCC_APB2PeriphClockCmd(LED1_PORT_RCC,ENABLE);
	GPIO_InitStructure2.GPIO_Pin=LED1_PIN|GPIO_Pin_8;
	GPIO_InitStructure2.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure2.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure2);
	
	GPIO_InitTypeDef m;
	RCC_APB2PeriphClockCmd(M_PORT_RCC,ENABLE);
	m.GPIO_Mode = GPIO_Mode_Out_PP;
	m.GPIO_Pin=GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
	m.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOG,&m);

}

void led1on()
{
	GPIO_ResetBits(GPIOE,LED2_PIN);
}

void led1off()
{
	GPIO_SetBits(GPIOE,LED2_PIN);
}

void led2on()
{
	GPIO_ResetBits(GPIOB,LED2_PIN);
}

void led2off()
{
	GPIO_SetBits(GPIOB,LED2_PIN);
}




