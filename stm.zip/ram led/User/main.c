#include"stm32f10x.h"
typedef unsigned int u32;
void SystemInit()
{
	


}

void delay(u32 a )
{
	while(a--);
}

int main ()
{
	while(1)
	{
		RCC_APB2ENR |= 1<<3;
		RCC_APB2ENR |= 1<<6;//
		GPIOB_CRL &= ~(0X0F<<(4*0));
		GPIOE_CRL &= ~(0X0F<<(4*0));
		GPIOB_CRL |= (3<<(4*5));
		GPIOE_CRL |= (3<<(4*5));
		//GPIOB_BSRR |= (1<<(16+5));
		//GPIOE_BSRR |=(1<<(16+5));
		while(1)
		{
			GPIOB_BSRR |= (1<<(16+5));
			delay(0xfffff);
			GPIOE_BSRR |= (1<<(16+5));
			delay(0xfffff);
			GPIOB_BSRR |= (1<<(+5));
			delay(0xfffff);
			GPIOE_BSRR |= (1<<(+5));
			delay(0xfffff);
			
		}
		
		
	}

}


