#include<LED.H>
#include<bitsContorl.h>
typedef unsigned int u32;
void del(u32 a)
{
	while(a--);
}



int main ()
{
	
	ledInit();
	
	while(1)
	{
		
		led1= !led1;
		del(0xffff);
		led2= !led2;
		del(0xffff);
	}
}
