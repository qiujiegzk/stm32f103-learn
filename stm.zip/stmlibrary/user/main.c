#include<stm32f10x.h>


int main ()
{
	while(1)
	{
		
	}
}
